import React from "react";
import { NavLink } from "react-router-dom";
import { Home, ShoppingCart, User } from "lucide-react";

const Footer = () => {
  return (
    <footer className="fixed bottom-0 left-0 w-full bg-white shadow-md border-t border-gray-200">
      <div className="flex justify-around items-center py-3">
        
        {/* Home */}
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex flex-col items-center text-sm ${
              isActive ? "text-red-500" : "text-gray-500"
            }`
          }
        >
          <Home size={22} />
          <span>Home</span>
        </NavLink>

        {/* Cart */}
        <NavLink
          to="/cart"
          className={({ isActive }) =>
            `flex flex-col items-center text-sm ${
              isActive ? "text-red-500" : "text-gray-500"
            }`
          }
        >
          <ShoppingCart size={22} />
          <span>Cart</span>
        </NavLink>

        {/* Profile */}
        <NavLink
          to="/profile"
          className={({ isActive }) =>
            `flex flex-col items-center text-sm ${
              isActive ? "text-red-500" : "text-gray-500"
            }`
          }
        >
          <User size={22} />
          <span>Profile</span>
        </NavLink>
      </div>
    </footer>
  );
};

export default Footer;
