import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { CartContext } from "../context/CartContext";

export default function Navbar() {
  const { token, logout } = useContext(AuthContext);
  const { cart } = useContext(CartContext);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-md fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 text-2xl font-bold text-red-600">
            FoodDelivery
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-6 items-center">
            <Link to="/" className="text-gray-700 hover:text-red-600">Home</Link>
            <Link to="/restaurants" className="text-gray-700 hover:text-red-600">Restaurants</Link>
            <Link to="/cart" className="relative text-gray-700 hover:text-red-600">
              Cart
              {cart.items.length > 0 && (
                <span className="absolute -top-2 -right-3 bg-red-600 text-white rounded-full px-2 text-xs">
                  {cart.items.length}
                </span>
              )}
            </Link>

            {token ? (
              <button
                onClick={logout}
                className="bg-red-600 text-white px-4 py-1 rounded hover:bg-red-700 transition"
              >
                Logout
              </button>
            ) : (
              <>
                <Link to="/login" className="text-gray-700 hover:text-red-600">Login</Link>
                <Link to="/register" className="text-gray-700 hover:text-red-600">Register</Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-600"
            >
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden px-2 pt-2 pb-3 space-y-1 bg-white shadow-md">
          <Link to="/" className="block px-3 py-2 text-gray-700 hover:bg-red-100 rounded">Home</Link>
          <Link to="/restaurants" className="block px-3 py-2 text-gray-700 hover:bg-red-100 rounded">Restaurants</Link>
          <Link to="/cart" className="block px-3 py-2 text-gray-700 hover:bg-red-100 rounded">
            Cart ({cart.items.length})
          </Link>
          {token ? (
            <button
              onClick={logout}
              className="w-full text-left px-3 py-2 text-gray-700 hover:bg-red-100 rounded"
            >
              Logout
            </button>
          ) : (
            <>
              <Link to="/login" className="block px-3 py-2 text-gray-700 hover:bg-red-100 rounded">Login</Link>
              <Link to="/register" className="block px-3 py-2 text-gray-700 hover:bg-red-100 rounded">Register</Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
}
