import React, { useState, useEffect } from 'react';

const FoodDeliveryApp = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [cartCount, setCartCount] = useState(0);
  const [favorites, setFavorites] = useState(new Set());
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const categories = [
    { id: 'pizza', name: '🍕 Pizza', count: 12 },
    { id: 'burger', name: '🍔 Burgers', count: 8 },
    { id: 'asian', name: '🍜 Asian', count: 15 },
    { id: 'healthy', name: '🥗 Healthy', count: 10 },
    { id: 'dessert', name: '🍰 Desserts', count: 6 },
    { id: 'coffee', name: '☕ Coffee', count: 9 },
  ];

  const restaurants = [
    {
      id: 1,
      name: "Mario's Italian Kitchen",
      category: 'pizza',
      rating: 4.8,
      reviews: 120,
      deliveryTime: '25-35',
      deliveryFee: 2.99,
      image: '🍕',
      tags: ['Italian', 'Pizza', 'Pasta'],
      promoted: true,
    },
    {
      id: 2,
      name: "Burger Palace",
      category: 'burger',
      rating: 4.6,
      reviews: 89,
      deliveryTime: '15-25',
      deliveryFee: 0,
      image: '🍔',
      tags: ['American', 'Burgers', 'Fries'],
    },
    {
      id: 3,
      name: "Sushi Zen",
      category: 'asian',
      rating: 4.9,
      reviews: 200,
      deliveryTime: '30-40',
      deliveryFee: 3.49,
      image: '🍣',
      tags: ['Japanese', 'Sushi', 'Fresh'],
    },
    {
      id: 4,
      name: "Green Bowl",
      category: 'healthy',
      rating: 4.7,
      reviews: 156,
      deliveryTime: '20-30',
      deliveryFee: 1.99,
      image: '🥗',
      tags: ['Healthy', 'Vegan', 'Salads'],
    },
  ];

  const filteredRestaurants = restaurants.filter(restaurant => {
    const matchesSearch = restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         restaurant.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = !selectedCategory || restaurant.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleFavorite = (restaurantId) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(restaurantId)) {
      newFavorites.delete(restaurantId);
    } else {
      newFavorites.add(restaurantId);
    }
    setFavorites(newFavorites);
  };

  const addToCart = () => {
    setCartCount(prev => prev + 1);
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-600 to-purple-700 text-white p-6 rounded-b-3xl shadow-lg">
        {/* Top Bar */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-2">
            <span className="text-lg">📍</span>
            <div>
              <p className="text-sm opacity-90">Deliver to</p>
              <p className="font-semibold">123 Main Street</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="relative p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <span className="text-xl">🛒</span>
              {cartCount > 0 && (
                <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                  {cartCount}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Greeting */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">
            {getGreeting()}, Alex! 👋
          </h1>
          <p className="text-white/90 text-lg">What are you craving today?</p>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search restaurants or food..."
            className="w-full bg-white/20 backdrop-blur-sm border border-white/30 rounded-2xl px-6 py-4 text-white placeholder-white/80 text-lg focus:outline-none focus:ring-2 focus:ring-white/50"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <span className="absolute right-6 top-1/2 transform -translate-y-1/2 text-2xl">🔍</span>
        </div>
      </div>

      {/* Categories */}
      <div className="px-6 py-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Categories</h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setSelectedCategory('')}
            className={`p-4 rounded-xl border-2 transition-all text-left ${
              !selectedCategory 
                ? 'border-blue-500 bg-blue-50 shadow-md' 
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div className="text-2xl mb-2">🍽️</div>
            <div className="font-semibold text-gray-800">All Categories</div>
            <div className="text-sm text-gray-500">{restaurants.length} restaurants</div>
          </button>
          
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`p-4 rounded-xl border-2 transition-all text-left ${
                selectedCategory === category.id 
                  ? 'border-blue-500 bg-blue-50 shadow-md' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="text-2xl mb-2">{category.name.split(' ')[0]}</div>
              <div className="font-semibold text-gray-800">{category.name.slice(2)}</div>
              <div className="text-sm text-gray-500">{category.count} places</div>
            </button>
          ))}
        </div>
      </div>

      {/* Restaurants */}
      <div className="px-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">
          {selectedCategory ? `${categories.find(c => c.id === selectedCategory)?.name.slice(2)} Restaurants` : 'Popular Near You'}
        </h2>

        {filteredRestaurants.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center shadow-sm">
            <div className="text-6xl mb-4">😔</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">No restaurants found</h3>
            <p className="text-gray-600 mb-4">Try searching for something else</p>
            <button 
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('');
              }}
              className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Reset Search
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRestaurants.map((restaurant) => (
              <div key={restaurant.id} className="bg-white rounded-2xl shadow-sm hover:shadow-lg transition-shadow">
                {/* Restaurant Header */}
                <div className="p-5">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center text-3xl">
                        {restaurant.image}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-gray-800">{restaurant.name}</h3>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <span>⭐ {restaurant.rating}</span>
                          <span>•</span>
                          <span>({restaurant.reviews} reviews)</span>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => toggleFavorite(restaurant.id)}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <span className="text-xl">
                        {favorites.has(restaurant.id) ? '❤️' : '🤍'}
                      </span>
                    </button>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {restaurant.tags.map((tag, index) => (
                      <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Badges */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {restaurant.promoted && (
                      <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium">
                        ⭐ Promoted
                      </span>
                    )}
                    {restaurant.deliveryFee === 0 && (
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                        🚚 Free Delivery
                      </span>
                    )}
                  </div>

                  {/* Bottom Info */}
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>⏱️ {restaurant.deliveryTime} min</span>
                      <span>🚚 {restaurant.deliveryFee === 0 ? 'Free' : `$${restaurant.deliveryFee}`}</span>
                    </div>
                    <button
                      onClick={addToCart}
                      className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                    >
                      Order Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex justify-around items-center max-w-md mx-auto">
          <button className="flex flex-col items-center space-y-1 text-blue-600">
            <span className="text-2xl">🏠</span>
            <span className="text-xs font-medium">Home</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-400">
            <span className="text-2xl">🔍</span>
            <span className="text-xs font-medium">Search</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-400 relative">
            <span className="text-2xl">🛒</span>
            <span className="text-xs font-medium">Cart</span>
            {cartCount > 0 && (
              <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {cartCount}
              </div>
            )}
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-400">
            <span className="text-2xl">👤</span>
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FoodDeliveryApp;